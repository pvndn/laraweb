<?php

namespace SundaySim\Events;

abstract class Event
{
    //
}
