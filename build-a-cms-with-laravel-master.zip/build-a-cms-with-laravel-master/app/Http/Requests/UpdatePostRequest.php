<?php

namespace SundaySim\Http\Requests;

use SundaySim\Http\Requests\Request;

class UpdatePostRequest extends StorePostRequest
{
    //
}
