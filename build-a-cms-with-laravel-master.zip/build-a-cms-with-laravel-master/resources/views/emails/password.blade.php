Follow the link to reset your password: {{ route('auth.password.reset', $token) }}
