<div style="min-height:500px;">
<h1> Welcome {{ get_users('name') }} </h1>
<a href="{{ trans_url('/user/package/module') }}">Sample package </a>
</div>