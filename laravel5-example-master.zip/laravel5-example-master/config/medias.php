<?php

return [

	/*
	|--------------------------------------------------------------------------
	| Url for filemanager
	|--------------------------------------------------------------------------
	*/

	'url' => 'filemanager/index.html',
	'url-files' =>'/public/filemanager/userfiles/'

];