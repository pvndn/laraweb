<?php

return [
	'title' => 'Formulário de contato',
	'text' => 'Se você deseja enviar uma mensagem, por favor preencha este formulário :',
	'name' => 'Seu nome',
	'email' => 'Seu email',
	'message' => 'Sua mensagem',
	'ok' => 'Sua mensagem foi gravada, nós vamos respondê-la assim que possível.'
];