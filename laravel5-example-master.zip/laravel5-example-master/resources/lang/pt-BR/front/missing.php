<?php

return [
	'error-404' => 'Erro 404',
	'info' => 'Esta página não existe !',
	'button' => 'Home'
];