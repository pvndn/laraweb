<?php

return [
	'button' => 'Leia mais',
	'on' => 'em',
	'updated' => ' atualizado em ',
	'tags' => 'Tags : ',
	'comments' => 'Comentários',
	'comment' => 'O comentário ?',
	'info-comment' => 'Você deve estar logado para adicionar um comentário !',
	'delete' => 'Deletar comentário',
	'edit' => 'Atualizar comentário',
	'change' => 'Alterara seu comentário em :',
	'valid' => 'Válido',
	'undo' => 'Desfazer',
	'fail-update' => 'Falha ao atualizar. Nenhum dado ou texto muito grande',
	'fail-delete' => 'Falha ao atualizar.',
	'warning' => 'Obrigado pelo seu comentário. Ele será publicado após um administrador validá-lo (Uma vez validado, seus outros comentários aparecem imediatamente)',
	'search' => 'Procurar no blog',
	'info-tag' => 'Posts encontrado com a tag ',
	'info-search' => 'Posts encontrados com a busca ',
	'confirm' => 'Realmente apagar este comentário ?'
];