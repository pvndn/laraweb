<?php

return [
	'connection' => 'Conexão',
	'text' => 'Para ingressar neste site você deve preencher este formulário :',
	'email' => 'Seu email',
	'password' => 'Sua senha',
	'remind' => 'Lembrar',
	'forget' => 'Eu esqueci minha senha !',
	'register' => 'Sem cadastro ?',
	'register-info' => 'Para se cadastrar rapidamente, clique no botão !',
	'registering' => 'Eu aceito',
	'credentials' => 'Estas credenciais não coincidem com nossos registros.',
	'log' => 'Seu email ou seu usuário',
	'maxattempt' => 'Você atingiu o número máximo de tentativas de login. Tente novamente em um minuto.'
];