<?php

return [
	'administration' => 'Administração',
	'redaction' => 'Redação',
	'home' => 'Voltar para o site',
	'logout' => 'Sair',
	'dashboard' => 'Painel',
	'users' => 'usuários',
	'see-all' => 'Ver todos',
	'add' => 'Adicionar',
	'messages' => 'Mensagens',
	'comments' => 'Comentários',
	'medias' => 'Mídias',
	'posts' => 'Posts',
	'new-messages' => 'Novos posts !',
	'new-registers' => 'Novos usuários !',
	'new-posts' => 'Novos posts !',
	'new-comments' => 'Novos comentários !'
];
