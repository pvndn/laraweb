<?php

return [
	'dashboard' => 'Gestão de Mídias',
	'medias' => 'Mídias'
];