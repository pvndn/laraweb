<?php

return [
	'dashboard' => 'Gestão de Mensagens',
	'messages' => 'Mensagens',
	'name' => 'Nome',
	'email' => 'Email',		
	'date' => 'Data',
	'seen' => 'revisado',
	'destroy' => 'Excluido',
	'destroy-warning' => 'Realmente destruir esta mensagem ?',
	'fail' => 'Falha na atualização.',
];