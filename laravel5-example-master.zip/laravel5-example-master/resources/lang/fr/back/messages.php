<?php

return [
	'dashboard' => 'Gestion des messages',
	'messages' => 'Messages',
	'name' => 'Nom',
	'email' => 'Email',		
	'date' => 'Date',
	'seen' => 'Vu',
	'destroy' => 'Supprimer',
	'destroy-warning' => 'Vraiment supprimer ce message ?',
	'fail' => 'Echec de la mise à jour.'	
];