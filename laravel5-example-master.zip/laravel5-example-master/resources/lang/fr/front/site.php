<?php

return [
	'title' => 'Laravel 5',
	'sub-title' => 'Un framework PHP novateur',
	'home' => 'Accueil',
	'contact' => 'Contact',
	'blog' => 'Blog',
	'register' => 'Inscription',
	'forget-password' => 'Oubli mot de passe',
	'connection' => 'Connexion',
	'administration' => 'Administration',
	'redaction' => 'Rédaction',
	'logout' => 'Déconnexion'
];
