<?php

return [
	'error-404' => 'Erreur 404',
	'info' => 'La page que vous demandez n\'existe pas !',
	'button' => 'Accueil du site'
];