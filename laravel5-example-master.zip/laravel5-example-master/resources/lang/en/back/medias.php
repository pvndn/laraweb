<?php

return [
	'dashboard' => 'Medias gestion',
	'medias' => 'Medias'
];