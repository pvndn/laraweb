<?php

return [
	'dashboard' => 'Posts gestion',
	'creation' => 'Creation',
	'published' => 'Published',
	'title' => 'Title',
	'permalink' => 'Permalink :',
	'summary' => 'Summary',
	'content' => 'Content',
	'tags' => 'Tags',
	'edition' => 'Edition',
	'add' => 'Add a post',
	'posts' => 'Posts',
	'date' => 'Date',
	'author' => 'Author',
	'seen' => 'Seen',
	'yes' => 'Yes',
	'no' => 'No',
	'see' => 'See',
	'edit' => 'Edit',
	'destroy' => 'Destroy',
	'destroy-warning' => 'Really destroy this post ?',
	'fail' => 'Update fail.',
	'stored' => 'Post stored.',
	'updated' => 'Post updated.',
	'destroyed' => 'Post destroyed'
];