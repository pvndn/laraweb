<?php

return [
    'video' 		=> 'Video',
    'album' 		=>  'Album',
    'album_cover' 	=> 'Album cover',
    'slider' 		=> 'Slider',
    'description' 	=> 'Description',
    'video' 		=> 'Video',
    'video_youtube' => 'Video from youtube.com'

];