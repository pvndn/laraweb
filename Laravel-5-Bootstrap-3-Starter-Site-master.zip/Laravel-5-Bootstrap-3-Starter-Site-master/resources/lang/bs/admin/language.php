<?php

return [
    'code' => 'Kod',
    'icon' => 'Ikona',
    'languages' => 'Jezici',

];