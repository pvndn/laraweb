<?php

return [
    'create' => 'Kreiranje',
    'edit' => 'Izmjena',
    'reset' => 'Reset',
    'cancel' => 'Odustati',
    'general' => 'Opšte',
    'title' => 'Naslov',
    'new' => 'Novo',
    'delete' => 'Obrisati',
    'items' => 'Stavke',
    'delete_message' => 'Da li ste sigurni da želite da obrišete ovu stavku?',
    'delete' => 'Brisanje',
];