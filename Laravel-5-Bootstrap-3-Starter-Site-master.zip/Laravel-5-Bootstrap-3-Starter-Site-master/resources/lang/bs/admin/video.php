<?php

return [
    'video' => 'Video',
    'album' =>  'Album',
    'album_cover' => 'Naslovni video',
    'slider' => 'Slider',
    'description' => 'Opis',
    'video' => 'Video',
    'video_youtube' => 'Video sa youtube.com'

];