<?php

return [
    'photoalbum' => 'Photo albums',
    'numbers_of_items' =>'Number of items',
    'description' => 'Description',


];