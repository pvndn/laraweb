<?php

return [
    'code' => 'Code',
    'icon' => 'Icon',
    'languages' => 'Languages',

];