<?php

return [
    'create' => 'Create',
    'edit' => 'Edit',
    'reset' => 'Reset',
    'cancel' => 'Cancel',
    'general' => 'General',
    'title' => 'Title',
    'new' => 'New',
    'delete' => 'Delete',
    'items' => 'Items',
    'delete_message' => 'Did you want to delete this item?',
];
