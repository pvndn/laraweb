<?php

return [
	'home' => 'Почетна',
	'login' => 'Пријава',
	'sign_up' => 'Регистрација',
	'admin_panel' => 'Админ дио',
	'logout' => 'Одјава',
	'login_as' => 'Пријавњени сте као',
	
];
