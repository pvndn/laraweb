<div class="jumbotron">
    <div class="container">
        <h1>{{$heading}}</h1>

        <p>{{$body}}</p>

    </div>
</div>