<?php

Route::get('dashboard', 'DashboardController@index')->name('admin.dashboard');