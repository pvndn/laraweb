<?php

namespace App\Services\Macros;

use Collective\Html\FormBuilder;

/**
 * Class Macros
 * @package App\Http
 */
class Macros extends FormBuilder
{
    use Dropdowns;
}