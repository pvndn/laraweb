Create a simple web catalog with private access.

We are have products (name, photo, model) and categories (title)
Product can belong to several categories (many to many)
Categories can be nested (like tree)
Users have two roles - admin and customer
Admin users are created using the database seeder

Admin can:
CRUD categories
CRUD goods
Show products, filter by category

Customer can:
Sign up
Show products, filter by category

Please do not waste time on html\css. 
Use laravel 5.1, mysql or postgresql and twitter bootstrap 3 or any css framework.
