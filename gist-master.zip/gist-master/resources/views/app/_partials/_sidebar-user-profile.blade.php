<div class="well">
    <img src="http://lorempixel.com/170/170/animals/" class="img-rounded">
    <h3>{{ '@'. $user->username }}</h3>
    <h5>{{ $user->name }}</h5>
</div>