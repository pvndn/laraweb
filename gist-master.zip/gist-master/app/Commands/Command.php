<?php namespace Gist\Commands;

abstract class Command {

	//

}
