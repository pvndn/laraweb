<?php namespace Gist\Events;

abstract class Event {

	//

}
