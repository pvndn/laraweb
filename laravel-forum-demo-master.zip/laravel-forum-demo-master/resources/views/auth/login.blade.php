@extends('app')

@section ('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Log in</div>
				<div class="panel-body">
					<form class="form-horizontal" role="form" method="POST" action="{{ url('auth/login') }}">
						<input type="hidden" name="_token" value="{{ csrf_token() }}">

						<div class="form-group">
							<label class="col-md-4 control-label">Select a user</label>
							<div class="col-md-6">
								<select name="email" class="form-control">
									<option value="user@forum.net">User</option>
									<option value="moderator@forum.net">Moderator</option>
									<option value="admin@forum.net">Admin</option>
								</select>
							</div>
						</div>

						<input type="hidden" name="password" value="demo321">

						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
								<div class="checkbox">
									<label>
										<input type="checkbox" name="remember"> Remember Me
									</label>
								</div>
							</div>
						</div>

						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
								<button type="submit" class="btn btn-primary">Login</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
