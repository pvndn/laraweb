@extends('app')

@section ('content')
<div class="alert alert-danger">Registration is disabled</div>
@endsection
