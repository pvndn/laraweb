@extends('app')

@section ('content')
<div class="alert alert-danger">Password reset is disabled</div>
@endsection
