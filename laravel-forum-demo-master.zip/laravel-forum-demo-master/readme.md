## Laravel forum package

See [Riari/laravel-forum](https://github.com/Riari/laravel-forum) for the package source and docs, or [laravel/laravel](https://github.com/laravel/laravel) for the Laravel framework.
